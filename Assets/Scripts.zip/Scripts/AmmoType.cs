using UnityEngine;

public enum AmmoType
{
    Pistol,
    SMG,
    Shotgun,
    Rifle
}

